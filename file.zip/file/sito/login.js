function login()
{
  var xmlhttp = new XMLHttpRequest();
      var user = document.getElementById("username").value;
      var pass = document.getElementById("password").value;
      var JSONdoc;
      var html = "";
      xmlhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) 
        {
          var risposta=this.responseText;
          if(risposta != false)
          {
            html="benvenuto "+risposta;
          }
          else
          {
            html="username o password sbagliati";
          }
          document.getElementById('utente').innerHTML=html;
        }
      };
      alert("username="+user+"&password="+pass+"");
      xmlhttp.open("POST","login.php", true);
      xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xmlhttp.send("user="+user+"&pass="+pass+"");
}