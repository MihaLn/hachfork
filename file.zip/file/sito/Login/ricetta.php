<?php
if($conn=mysqli_connect("localhost","root","","make_easy"))
{
  $idR=$_GET["idR"];
  $row=mysqli_fetch_assoc(mysqli_query($conn,"Select nome,tempo,kcal,procedimento,quantita,tipologia From ricette where idR='$idR'"));
  echo $html="<h1>nome: ".$row['nome']."</h1><br><h1>tempo:".$row['nome']." Kcal:".$row['kcal']." tipologia: ".$row['tipologia']."</h1><br><h3>quantità:".$row['quantita']."</h3><br><h3>procedimento:".$row['procedimento']."</h3>";
}
mysqli_close($conn);
?>