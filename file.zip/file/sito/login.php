<?php
$db="make_easy";
if($conn=mysqli_connect("localhost","root","",$db))
{
    $username="";
    $password="";
    if(isset($_POST["user"]))
    {
        $username=$_POST["user"];
    }
    if(isset($_POST["pass"]))
    {
        $password=md5($_POST["pass"]);
    }
    //echo "**".$username."**";
    //$password=md5($_POST["password"]);
    $q="Select password,idUtente,nome,cognome From utenti Where username='$username';";
    //echo $q;
    if($result=mysqli_query($conn,$q))
    {
        if(mysqli_num_rows($result)==1)
        {
            $row=mysqli_fetch_assoc($result);
            //echo $row['password'];
            if($row['password']==$password)
            {
                session_start();
                $_SESSION['username']=$username;
                $_SESSION['idUtente']=$row['idUtente'];
                echo $row['nome']." ".$row['cognome'];
            }
            else
            {
                echo "1";
            }
        }
        else
        {
            echo "2";
        }
    }
    else
    {
        echo "3";
    }
}
else
{
    echo "4";
}
mysqli_close($conn);
?>